import os
from openai import OpenAI
from dotenv import load_dotenv

# Load environment variables
load_dotenv()
client = OpenAI(api_key=os.getenv("OPENAI_API_KEY"))

# Function to determine a player's archetype based on trait ratings
def determine_archetype(ratings):
    if ratings.get("Shooting", 0) >= 7 and ratings.get("Perimeter Defense", 0) >= 7 and ratings.get("Motor", 0) >= 7:
        return "3&D Wing"
    if ratings.get("Playmaking", 0) >= 8 and ratings.get("Ball Handling", 0) >= 7 and ratings.get("Shooting", 0) >= 6:
        return "Playmaking Guard"
    if ratings.get("Finishing", 0) >= 8 and ratings.get("Athleticism", 0) >= 8 and ratings.get("Ball Handling", 0) >= 6:
        return "Athletic Slasher"
    if ratings.get("Post Defense", 0) >= 8 and ratings.get("Rebounding", 0) >= 8 and ratings.get("Finishing", 0) >= 7:
        return "Post Specialist"
    if (ratings.get("Help Defense", 0) >= 7 and ratings.get("IQ", 0) >= 7
            and ratings.get("Finishing", 0) >= 7 and ratings.get("Motor", 0) >= 7):
        return "Two-Way Forward"
    if (ratings.get("Post Defense", 0) >= 8 and ratings.get("Help Defense", 0) >= 8
            and ratings.get("Rebounding", 0) >= 8):
        return "Defensive Anchor"
    return "Versatile Prospect"

# Function to generate the OpenAI summary
def generate_summary(report):
    ratings = report.get("ratings", {})
    archetype = determine_archetype(ratings)

    prompt = f"""Generate a 5–7 sentence NBA draft scouting summary based on the following evaluation:
Strengths: {report['strengths']}
Weaknesses: {report['weaknesses']}
Intangibles: {report.get('intangibles', 'N/A')}
Player Comparison: {report['comparison']}
Projected Role: {report['role']}
Ceiling: {report['ceiling']}
Draft Range: {report['range']}
Archetype: {archetype}

From the trait ratings below, highlight strengths with a rating of 8 or higher and weaknesses with a rating of 3 or lower — but do not repeat traits already mentioned in the Strengths or Weaknesses section.

Trait Ratings:
{ratings}
"""

    response = client.chat.completions.create(
        model="gpt-3.5-turbo",
        messages=[{"role": "user", "content": prompt}],
        temperature=0.7,
        max_tokens=300,
    )

    return response.choices[0].message.content.strip()
