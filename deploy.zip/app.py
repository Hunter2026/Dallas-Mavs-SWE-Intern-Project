import os
from flask import Flask, send_from_directory, request, jsonify
from flask_cors import CORS
from generator import generate_summary

application = Flask(__name__, static_folder='static', static_url_path='')
CORS(application)

# API endpoint
@application.route('/summary', methods=['POST'])
def summary_api():
    try:
        report = request.get_json()
        summary = generate_summary(report)
        return jsonify({"summary": summary}), 200
    except Exception as e:
        return jsonify({"error": str(e)}), 400

# Health check
@application.route('/ping')
def ping():
    return 'pong', 200

# Catch-all frontend route
@application.route('/', defaults={'path': ''})
@application.route('/<path:path>')
def serve_react(path):
    # Always serve the file if it exists
    full_path = os.path.join(application.static_folder, path)
    if os.path.isfile(full_path):
        return send_from_directory(application.static_folder, path)

    # Otherwise, serve index.html (for React Router fallback)
    return send_from_directory(application.static_folder, 'index.html')
